<?php

namespace App\Entity;

use App\Repository\ProductosPedidoRepository;
use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass=ProductosPedidoRepository::class)
 */
class ProductosPedido
{
    /**
     * @ORM\Id
     * @ORM\GeneratedValue
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\ManyToOne(targetEntity=Producto::class, inversedBy="productosPedidos")
     */
    private $producto;

    /**
     * @ORM\ManyToOne(targetEntity=Pedido::class, inversedBy="productosPedidos")
     */
    private $pedido;

    /**
     * @ORM\Column(type="integer")
     */
    private $cantidad;

    public function __toString()
    {
        return $this->getProducto()->getRef()."-".$this->getProducto()->getNombre()."-Cantidad: ".$this->cantidad;
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getProducto(): ?Producto
    {
        return $this->producto;
    }

    public function setProducto(?Producto $producto): self
    {
        $this->producto = $producto;

        return $this;
    }

    public function getPedido(): ?Pedido
    {
        return $this->pedido;
    }

    public function setPedido(?Pedido $pedido): self
    {
        $this->pedido = $pedido;

        return $this;
    }

    public function getCantidad(): ?int
    {
        return $this->cantidad;
    }

    public function setCantidad(int $cantidad): self
    {
        $this->cantidad = $cantidad;

        return $this;
    }
}
